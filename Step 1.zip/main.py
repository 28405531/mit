from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import re

# Sample data (you can replace this with your own data storage)
tasks = [
    {
        'id': 1,
        'title': 'Task 1',
        'description': 'This is task 1',
        'done': False
    },
    {
        'id': 2,
        'title': 'Task 2',
        'description': 'This is task 2',
        'done': False
    }
]

class APIServer(BaseHTTPRequestHandler):
    def _set_headers(self, status_code=200, content_type='application/json'):
        self.send_response(status_code)
        self.send_header('Content-type', content_type)
        self.end_headers()

    def do_GET(self):
        if re.match(r'^/tasks$', self.path):
            self._set_headers()
            self.wfile.write(json.dumps({'tasks': tasks}).encode())
        elif re.match(r'^/tasks/\d+$', self.path):
            task_id = int(self.path.split('/')[-1])
            task = next((task for task in tasks if task['id'] == task_id), None)
            if task:
                self._set_headers()
                self.wfile.write(json.dumps({'task': task}).encode())
            else:
                self._set_headers(404)
                self.wfile.write(json.dumps({'message': 'Task not found'}).encode())
        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({'message': 'Not found'}).encode())

    def do_POST(self):
        if re.match(r'^/tasks$', self.path):
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            new_task = json.loads(post_data.decode())
            new_task['id'] = max(task['id'] for task in tasks) + 1
            tasks.append(new_task)
            self._set_headers(201)
            self.wfile.write(json.dumps({'task': new_task}).encode())
        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({'message': 'Not found'}).encode())

    def do_DELETE(self):
        if re.match(r'^/tasks/\d+$', self.path):
            task_id = int(self.path.split('/')[-1])
            global tasks
            tasks = [task for task in tasks if task['id'] != task_id]
            self._set_headers()
            self.wfile.write(json.dumps({'message': 'Task deleted successfully'}).encode())
        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({'message': 'Not found'}).encode())

def run(server_class=HTTPServer, handler_class=APIServer, port=8000):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f'Starting server on port {port}...')
    httpd.serve_forever()

if __name__ == '__main__':
    run()
