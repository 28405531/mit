from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

app = FastAPI()

# Define a Pydantic model for Task
class Task(BaseModel):
    id: int
    title: str
    description: str
    done: bool

# Sample data (you can replace this with your own data storage)
tasks = [
    Task(id=1, title='Task 1', description='This is task 1', done=False),
    Task(id=2, title='Task 2', description='This is task 2', done=False)
]

@app.get("/tasks", response_model=List[Task])
async def read_tasks():
    return tasks

@app.get("/tasks/{task_id}", response_model=Task)
async def read_task(task_id: int):
    task = next((task for task in tasks if task.id == task_id), None)
    if task:
        return task
    else:
        raise HTTPException(status_code=404, detail="Task not found")

@app.post("/tasks", response_model=Task, status_code=201)
async def create_task(new_task: Task):
    new_task.id = max(task.id for task in tasks) + 1
    tasks.append(new_task)
    return new_task

@app.put("/tasks/{task_id}", response_model=Task)
async def update_task(task_id: int, updated_task: Task):
    task_index = next((index for index, task in enumerate(tasks) if task.id == task_id), None)
    if task_index is not None:
        tasks[task_index] = updated_task
        return updated_task
    else:
        raise HTTPException(status_code=404, detail="Task not found")

@app.delete("/tasks/{task_id}")
async def delete_task(task_id: int):
    global tasks
    tasks = [task for task in tasks if task.id != task_id]
    return {"message": "Task deleted successfully"}
